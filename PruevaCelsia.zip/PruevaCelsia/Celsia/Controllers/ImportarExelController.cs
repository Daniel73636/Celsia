using Celsia.Data;
using Celsia.Models;
using Celsia.Models.DTOS;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace GenerarExel.Controllers
{
    public class ImportarExelController : Controller
    {
        public readonly CelsiaDBContext _context;

        public ImportarExelController(CelsiaDBContext context)
        {
            _context = context;
        }

        // Método que se encarga de leer un archivo Excel cargado por el usuario
        public async Task<IActionResult> ReadExcelFile(IFormFile file)
        {
            // Verificar si se ha seleccionado un archivo
            if (file == null || file.Length == 0)
                return Content("Archivo no seleccionado");

            // Verificar la extensión del archivo para asegurarse de que es un archivo Excel
            string fileExtension = Path.GetExtension(file.FileName);
            if (fileExtension != ".xls" && fileExtension != ".xlsx")
                return Content("Archivo no seleccionado");

            using (var stream = new MemoryStream())
            {
                // Copiar el archivo a un stream en memoria
                await file.CopyToAsync(stream);
                stream.Position = 0;

                // Crear un paquete de Excel a partir del stream
                using (var package = new ExcelPackage(stream))
                {
                    // Obtener la hoja de cálculo llamada "Sheet1"
                    ExcelWorksheet workSheet = package.Workbook.Worksheets["Sheet1"];
                    if (workSheet == null)
                        return Content("Hoja de Excel no encontrada");

                    // Obtener el número total de filas en la hoja de cálculo
                    int totalRows = workSheet.Dimension.Rows;

                    // Crear una lista para almacenar los datos de los estudiantes
                    var studentList = new List<UsuarioDTO>();
                    for (int i = 2; i <= totalRows; i++) // Comenzar desde la segunda fila (asumiendo que la primera fila contiene encabezados)
                    {
                        // Crear un nuevo UsuarioDTO con los datos de cada fila
                        var usuarioDTO = new UsuarioDTO
                        {
                            Nombre = workSheet.Cells[i, 1].Value?.ToString(),
                            Documento = workSheet.Cells[i, 2].Value?.ToString(),
                            Correo = workSheet.Cells[i, 3].Value?.ToString(),
                            Direccion = workSheet.Cells[i, 4].Value?.ToString(),
                            Telefono = workSheet.Cells[i, 5].Value?.ToString(),
                        };

                        // Validar el correo y documento en base de datos
                        if (_context.Usuario.Any(u => u.Correo == usuarioDTO.Correo))
                        {
                            ModelState.AddModelError("Correo", $"El correo {usuarioDTO.Correo} ya está registrado.");
                            continue; // Saltar al siguiente registro
                        }

                        if (_context.Usuario.Any(u => u.Documento == usuarioDTO.Documento))
                        {
                            ModelState.AddModelError("Documento", $"El documento {usuarioDTO.Documento} ya está registrado.");
                            continue; // Saltar al siguiente registro
                        }

                        // Agregar el UsuarioDTO a la lista
                        studentList.Add(usuarioDTO);
                    }

                    // Agregar los usuarios a la base de datos
                    foreach (var usuarioDTO in studentList)
                    {
                        // Convertir UsuarioDTO a Usuario
                        Usuario usuario = usuarioDTO.ConvertirAUsuario(usuarioDTO);
                        usuario.Estado = "Activo"; // Asignar estado "Activo"

                        // Agregar el objeto Usuario al contexto
                        await _context.Usuario.AddAsync(usuario);
                    }

                    // Guardar los cambios en la base de datos
                    await _context.SaveChangesAsync();
                }
            }

            // Devolver una respuesta de éxito
            return Ok("Datos importados exitosamente.");
        }

        public IActionResult ExelView()
        {
            return View();
        }
    }
}

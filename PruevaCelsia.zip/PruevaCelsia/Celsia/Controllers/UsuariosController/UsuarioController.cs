using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Celsia.Data;
using Celsia.Models;
using Celsia.Models.DTOS;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Celsia.Controllers.UsuariosController
{
    public class UsuarioController : Controller
    {
        public readonly CelsiaDBContext _context;
        public UsuarioController(CelsiaDBContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
{
    // Filtra los usuarios que tienen el estado "Activo" y el rolid igual a 2
    var usuariosActivos = await _context.Usuario
        .Where(u => u.Estado == "Activo" && u.RoleId == 2)
        .ToListAsync();

    return View(usuariosActivos);
}


        public async Task<IActionResult> IndexPapelera()
        {
            // Filtra los usuarios que tienen el estado "Activo"
            var usuariosInactivos = await _context.Usuario
                .Where(u => u.Estado == "Inactivo")
                .ToListAsync();

            return View(usuariosInactivos);
        }



        public IActionResult CrearView()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Crear(UsuarioDTO usuarioDTO)
        {
            // Verificar si el correo ya existe en la base de datos
            bool correoExistente = _context.Usuario.Any(u => u.Correo == usuarioDTO.Correo);

            if (correoExistente)
            {
                // Si el correo ya existe, mostrar un mensaje de error
                ModelState.AddModelError("Correo", "El correo electrónico ya está registrado.");
            }

            // Verificar si el documento ya existe en la base de datos
            bool documentoExistente = _context.Usuario.Any(u => u.Documento == usuarioDTO.Documento);

            if (documentoExistente)
            {
                // Si el documento ya existe, mostrar un mensaje de error
                ModelState.AddModelError("Documento", "El Documento ya está registrado.");
            }

            // Si hay errores en el ModelState, devolver la vista con los errores
            if (!ModelState.IsValid)
            {
                return View("CrearView", usuarioDTO); // Devuelve la vista con el DTO para que el usuario pueda corregir
            }

            // Convertir UsuarioDTO a Usuario
            Usuario usuario = usuarioDTO.ConvertirAUsuario(usuarioDTO);
            usuario.Estado = "Activo";
            // Agregar el objeto Usuario al contexto
            _context.Usuario.Add(usuario);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Detalles(int? id)
        {
            return View(await _context.Usuario.FirstOrDefaultAsync(m => m.Id == id));
        }

        [HttpGet]
        public async Task<IActionResult> EditarView(int? id)
        {
            return View(await _context.Usuario.FirstOrDefaultAsync(m => m.Id == id));
        }

        [HttpPost]
        public async Task<IActionResult> EditarView(int? id, Usuario usuario)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Busca el usuario en la base de datos por su ID
            var usuarioExistente = await _context.Usuario.FindAsync(id);
            if (usuarioExistente == null)
            {
                return NotFound();
            }

            // Actualiza las propiedades del usuario existente
            usuarioExistente.Nombre = usuario.Nombre;
            usuarioExistente.Documento = usuario.Documento;
            usuarioExistente.Direccion = usuario.Direccion;
            usuarioExistente.Telefono = usuario.Telefono;
            usuarioExistente.Correo = usuario.Correo;

            // Guarda los cambios
            _context.Usuario.Update(usuarioExistente);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Usuario");
        }

        public async Task<IActionResult> Eliminar(int? id)
        {
            var usuarioExistente = await _context.Usuario.FindAsync(id);
            if (usuarioExistente == null)
            {
                return NotFound();
            }

            // Actualiza el estado del usuario existente
            usuarioExistente.Estado = "Inactivo";

            // Guarda los cambios
            _context.Usuario.Update(usuarioExistente);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Usuario");
        }

    }
}
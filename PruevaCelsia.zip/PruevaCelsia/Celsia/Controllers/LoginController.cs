using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Celsia.Controllers.UsuariosController;
using Celsia.Data;
using Celsia.Models;
using Microsoft.AspNetCore.Mvc;

namespace Celsia.Controllers
{
    public class LoginController : Controller
    {
        public readonly CelsiaDBContext _context;
        public LoginController(CelsiaDBContext context)
        {
            _context = context;
        }

        public IActionResult LoginView(){
            return View();
        }

        [HttpPost]
        public IActionResult LoginView(string correo, string contrasena)
        {
            // Busca el usuario que coincida con el correo y la contraseña proporcionados
            var usuario = _context.Usuario
                .FirstOrDefault(u => u.Correo == correo && u.Contrasena == contrasena);

            // Verifica si se encontró el usuario y si tiene el rol adecuado (RoleId == 1)
            if (usuario != null && usuario.RoleId == 1)
            {
                return RedirectToAction("Index","Usuario");
            }
            else
            {
                // En lugar de NotFound, podrías considerar devolver una vista de error o un mensaje de login fallido
                return RedirectToAction("CredencialesIncorrectas");
            }
        }

        public IActionResult CredencialesIncorrectas(){
            return View();
        }


    }
}
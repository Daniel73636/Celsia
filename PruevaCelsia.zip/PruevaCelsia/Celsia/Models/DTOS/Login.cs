using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Celsia.Models;

namespace Celsia.Models.DTOS
{
    public class Login
    {
        public required string Correo { get; set; }
        public required string Contrasena { get; set; }
        public required string Nombre { get; set; }
        public required string Documento { get; set; }
        public required string Direccion { get; set;}
        public required string Telefono { get; set; }
        public int RoleId { get; set; }

        // Método para convertir Login a Usuario
        public Usuario ConvertirALogin(Login login)
        {
            return new Usuario
            {
                Nombre = login.Nombre,
                Documento = login.Documento,
                Direccion  = login.Direccion,
                Telefono = login.Telefono,
                RoleId = login.RoleId,
                Correo = login.Correo,
                Contrasena = login.Contrasena
            };
        }
    }
}

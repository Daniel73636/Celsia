using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Celsia.Models.DTOS
{
    public class UsuarioDTO
    {
        public required string Nombre { get; set; }
        public required string Documento { get; set; }
        public required string Direccion { get; set;}
        public required string Telefono { get; set; }
        public required string Correo { get; set; }
        public  string Contrasena { get; set; }
        public int RoleId { get; set; } = 2;
        public Usuario ConvertirAUsuario(UsuarioDTO usuarioDTO){
            return  new(){
                Nombre = usuarioDTO.Nombre,
                Documento = usuarioDTO.Documento,
                Direccion  = usuarioDTO.Direccion,
                Telefono = usuarioDTO.Telefono,
                Correo = usuarioDTO.Correo,
                Contrasena = usuarioDTO.Contrasena,
                RoleId = usuarioDTO.RoleId
            };
        }
    }
}
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Celsia.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public required string Nombre { get; set; }
        public required string Documento { get; set; }
        public required string Direccion { get; set;}
        public required string Telefono { get; set; }
        public required string Correo { get; set; }
        public required string Contrasena { get; set; }
        public int RoleId { get; set; } 
        public string? Estado { get; set; }
    }
}
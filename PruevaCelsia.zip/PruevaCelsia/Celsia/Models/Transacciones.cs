using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Celsia.Models
{
    public class Transacciones
    {
        public int Id { get; set;}
        public DateTime Fecha { get; set;}
        public decimal Monto { get; set;}
        public int PlataFormasDePagoId {get; set;}
        public required string Estado {get; set;}
        public required string NumeroFactura {get; set;}
        public DateTime PeriodoFacturacion {get; set;}
        public decimal MontoFacturado {get; set;}
        public decimal MontoPagado {get; set;}
        public int UsuarioId {get; set;}
    }
}
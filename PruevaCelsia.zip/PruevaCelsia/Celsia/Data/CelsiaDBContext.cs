using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Celsia.Models;
using Microsoft.EntityFrameworkCore;

namespace Celsia.Data
{
    public class CelsiaDBContext : DbContext
    {
        public CelsiaDBContext(DbContextOptions<CelsiaDBContext> options) : base(options){

        }
        public DbSet<Usuario> Usuario {get; set; }
        public DbSet<Transacciones> Transacciones {get; set; }
        public DbSet<Roles> Roles {get; set; }
        public DbSet<PlataFormasDePago> PlataFormasDePago {get; set; }
    }
}